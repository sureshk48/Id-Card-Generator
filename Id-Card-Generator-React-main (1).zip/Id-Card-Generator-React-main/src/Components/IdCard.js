import React ,{useState}from 'react'
import './idCard.css'
function IdCard() {
    const [formData, setFormData] = useState({
        name: '',
        dob: '',
        stack: '',
        idNumber: '',
        issueDate: '',
        expiryDate: '',
        companyName: 'Pentagon Space',
        companyService: 'Education Platform',
      });
    const[Image,setImage]=useState(null)
      const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
      };
      const handleImageUpload = (event) => {
        const file = event.target.files[0]; // Get the first selected file
        if (file) {
          const imageUrl = URL.createObjectURL(file); // Create a temporary URL for the image
          setImage(imageUrl);
        }
      };
  return (
    <>
     <div className="conatiner">
      <h1 className='heading'>ID Card Generator</h1>
      <div className="form">
        <input
          type="text"
          name="name"
          placeholder="Name"
          value={formData.name}
          onChange={handleChange}
        />
        <input
          type="date"
          name="dob"
          placeholder="Date of Birth"
          value={formData.dob}
          onChange={handleChange}
        />
        <input
          type="text"
          name="position"
          placeholder="Course"
          value={formData.stack}
          onChange={handleChange}
        />
        <input
          type="text"
          name="idNumber"
          placeholder="ID Number"
          value={formData.idNumber}
          onChange={handleChange}
        />
        <input
          type="month"
          name="issueDate"
          placeholder="Issue Date"
          value={formData.issueDate}
          onChange={handleChange}
        />
        <input
          type="month"
          name="expiryDate"
          placeholder="Expiry Date"
          value={formData.expiryDate}
          onChange={handleChange}
        />
      <input type="file" accept="image/*" onChange={handleImageUpload} />
      {/* accept="image/*" → Ensures that only image files can be selected.
image/* → Means any image format (JPEG, PNG, GIF, WebP, etc.).
If this attribute is not used, the user can select any file type (PDFs, videos, etc.). */}
      </div>
      <div className="card-preview">
        <div className="id-card">
          <h2>IDENTIFICATION CARD</h2>
          <div className="card-content">
            <div >
            <img
            src={Image}
            alt="No Image"
           height='100' width='100'
          />
          <h3 style={{textAlign:"center"}}>Photo</h3>
            </div>
            <div className="details">
              <p><strong>Name:</strong> {formData.name || 'Your Name'}</p>
              <p><strong>D.O.B:</strong> {formData.dob || 'Your DOB'}</p>
              <p><strong>Stack:</strong> {formData.position || 'Your Course'}</p>
              <p><strong>ID No:</strong> {formData.idNumber || 'Your ID'}</p>
              <p><strong>Issued:</strong> {formData.issueDate || 'Issue Date'}</p>
              <p><strong>Expires:</strong> {formData.expiryDate || 'Expiry Date'}</p>
            </div>
          </div>
          <div className="company">
            <h3>{formData.companyName}</h3>
            <p>{formData.companyService}</p>
          </div>
        </div>
      </div>
    </div> 
    </>
  )
}

export default IdCard
