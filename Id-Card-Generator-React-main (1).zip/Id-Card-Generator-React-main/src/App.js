import React from "react";
import IdCard from "./Components/IdCard";

function App() {
  return (
    <div>
      <IdCard/>
    </div>
  );
}

export default App;
